package controlador;

import dao.MascotasDAO;
import modelo.Mascota;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

@WebServlet("/registroMascota")
public class RegistroMascota extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener datos del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String mascotaT = request.getParameter("mascotaT");

        // Crear un objeto Mascota con los datos
        Mascota mascota = new Mascota();
        mascota.setNombre(nombre);
        mascota.setApellido(apellido);
        mascota.setMascotaT(mascotaT);

        // Obtener la fecha actual
        java.util.Date fechaActual = new java.util.Date(); //es una forma de utilizar la clase sin necesitar una declaracion 'import'
        mascota.setFechaAlta(new Date(fechaActual.getTime()));

        // Agregar el mascota a la base de datos
        MascotasDAO mascotasDAO = new MascotasDAO();
        mascotasDAO.agregarMascota(mascota);

        // Redireccionar a la página de visualización de mascotas
        response.sendRedirect(request.getContextPath() + "/vistas/verMascotas.jsp");
    }
}
