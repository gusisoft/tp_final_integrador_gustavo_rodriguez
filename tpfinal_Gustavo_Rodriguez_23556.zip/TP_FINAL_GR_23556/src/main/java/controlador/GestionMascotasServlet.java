package controlador;

import dao.MascotasDAO;
import modelo.Mascota;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/vistas/GestionMascotaServlet")
public class GestionMascotasServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = request.getParameter("accion");
        MascotasDAO mascotasDAO = new MascotasDAO();

        // Inicializar idMascota antes del switch para que esté disponible en todos los casos
        int idMascota = Integer.parseInt(request.getParameter("id"));

        switch (accion) {
            case "actualizar":
                Mascota mascota = mascotasDAO.obtenerPorId(idMascota);
                request.setAttribute("mascota", mascota); //Esto permite pasar datos del servlet a una vista (como un archivo JSP) o a otro servlet al que se redirige o se reenvía la solicitud
                request.getRequestDispatcher("actualizar.jsp").forward(request, response);
                break;
            case "confirmarActualizacion":
                Mascota mascotaActualizado = new Mascota();
                mascotaActualizado.setIdMascota(idMascota);
                mascotaActualizado.setNombre(request.getParameter("nombre"));
                mascotaActualizado.setApellido(request.getParameter("apellido"));
                mascotaActualizado.setMascotaT(request.getParameter("mascotaT"));
                // Asume que el método setFechaAlta acepta un java.sql.Date
                mascotaActualizado.setFechaAlta(java.sql.Date.valueOf(request.getParameter("fechaAlta")));

                mascotasDAO.actualizarMascota(mascotaActualizado);
                response.sendRedirect("gestionMascotas.jsp");
                break;
            case "eliminar":
                mascotasDAO.eliminarMascota(idMascota);
                response.sendRedirect("gestionMascotas.jsp");
                break;
            default:
                response.sendRedirect("gestionMascotas.jsp");
                break;
        }
    }
}
