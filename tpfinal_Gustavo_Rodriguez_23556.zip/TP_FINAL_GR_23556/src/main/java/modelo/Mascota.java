package modelo;

import java.sql.Date;

public class Mascota {
    private int idMascota;
    private String nombre;
    private String apellido;
    private String mascotaT;
    private Date fechaAlta;

    // Constructor
    public Mascota() {
    }

    // Getters y setters
    // ...

    // Resto de métodos y atributos
    // ...

    public int getIdMascota() {
        return idMascota;
    }

    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getMascotaT() {
        return mascotaT;
    }

    public void setMascotaT(String mascotaT) {
        this.mascotaT = mascotaT;
    }

    public Date getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }
}

